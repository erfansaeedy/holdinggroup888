// ====== SPA Navigation ======
const links = document.querySelectorAll('nav a');
const pages = document.querySelectorAll('.page');
let currentPage = 'home';
let currentLang = 'fa';

function showPage(target) {
  pages.forEach(p => p.hidden = p.id !== target);
  links.forEach(a => a.setAttribute('aria-current', a.dataset.page === target ? 'page' : 'false'));
  currentPage = target;
  document.title = titles[currentLang][target] + ' • Holding Group 888';
}

links.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const target = link.getAttribute('data-page');
    showPage(target);
  });
});

// ====== i18n ======
const translations = {
  fa: {
    nav: { home: 'صفحه اصلی', about: 'درباره ما', services: 'خدمات', contact: 'تماس با ما' },
    home: { title: 'به Holding Group 888 خوش آمدید', desc: 'شرکت ما در زمینه حواله ارزی و حمل‌ونقل بین‌المللی هوایی، ریلی، دریایی و زمینی فعالیت می‌کند.' },
    about: { title: 'درباره ما', desc: 'Holding Group 888 با سال‌ها تجربه در حوزه حواله ارزی و حمل‌ونقل بین‌المللی، خدماتی مطمئن و سریع را به مشتریان خود ارائه می‌دهد.' },
    services: { title: 'خدمات ما', service1_title: 'حواله ارزی', service1_desc: 'ارائه خدمات حواله ارزی با سرعت و امنیت بالا برای مشتریان داخلی و بین‌المللی.', service2_title: 'حمل‌ونقل بین‌المللی', service2_desc: 'حمل‌ونقل از طریق راه‌های هوایی، ریلی، دریایی و زمینی با بهترین شرایط و قیمت‌ها.' },
    contact: { title: 'تماس با ما', name: 'نام:', email: 'ایمیل:', subject: 'موضوع:', message: 'پیام:', send: 'ارسال', sent: 'پیام شما ارسال شد!' }
  },
  en: {
    nav: { home: 'Home', about: 'About', services: 'Services', contact: 'Contact' },
    home: { title: 'Welcome to Holding Group 888', desc: 'We operate in currency transfer and international transportation via air, rail, sea, and land.' },
    about: { title: 'About Us', desc: 'With years of experience in currency transfer and international transport, we provide reliable and fast services.' },
    services: { title: 'Our Services', service1_title: 'Currency Transfer', service1_desc: 'Fast and secure currency transfer services for domestic and international clients.', service2_title: 'International Logistics', service2_desc: 'Air, rail, sea, and land transportation with optimal conditions and pricing.' },
    contact: { title: 'Contact Us', name: 'Name:', email: 'Email:', subject: 'Subject:', message: 'Message:', send: 'Send', sent: 'Your message has been sent!' }
  },
  zh: {
    nav: { home: '首页', about: '关于我们', services: '服务', contact: '联系我们' },
    home: { title: '欢迎来到 Holding Group 888', desc: '我们从事货币转账以及空运、铁路、海运和陆路的国际运输。' },
    about: { title: '关于我们', desc: '凭借多年的货币转账与国际运输经验，我们为客户提供可靠而快速的服务。' },
    services: { title: '我们的服务', service1_title: '货币转账', service1_desc: '为国内外客户提供高速且安全的货币转账服务。', service2_title: '国际物流', service2_desc: '通过空运、铁路、海运和陆路提供最佳条件与价格的运输服务。' },
    contact: { title: '联系我们', name: '姓名：', email: '电子邮件：', subject: '主题：', message: '信息：', send: '发送', sent: '您的信息已发送！' }
  }
};

const titles = {
  fa: { home: 'صفحه اصلی', about: 'درباره ما', services: 'خدمات', contact: 'تماس با ما' },
  en: { home: 'Home', about: 'About', services: 'Services', contact: 'Contact' },
  zh: { home: '首页', about: '关于我们', services: '服务', contact: '联系我们' }
};

const langSelect = document.getElementById('lang-select');

function applyTranslations(lang) {
  // Update nav
  document.querySelector('nav a[data-page="home"]').textContent = translations[lang].nav.home;
  document.querySelector('nav a[data-page="about"]').textContent = translations[lang].nav.about;
  document.querySelector('nav a[data-page="services"]').textContent = translations[lang].nav.services;
  document.querySelector('nav a[data-page="contact"]').textContent = translations[lang].nav.contact;

  // Home
  document.querySelector('#home h1').textContent = translations[lang].home.title;
  document.querySelector('#home p').textContent = translations[lang].home.desc;

  // About
  document.querySelector('#about h2').textContent = translations[lang].about.title;
  document.querySelector('#about p').textContent = translations[lang].about.desc;

  // Services
  document.querySelector('#services h2').textContent = translations[lang].services.title;
  const serviceBoxes = document.querySelectorAll('#services .service');
  serviceBoxes[0].querySelector('[data-i18n-key="service1_title"]').textContent = translations[lang].services.service1_title;
  serviceBoxes[0].querySelector('p').textContent = translations[lang].services.service1_desc;
  serviceBoxes[1].querySelector('[data-i18n-key="service2_title"]').textContent = translations[lang].services.service2_title;
  serviceBoxes[1].querySelector('p').textContent = translations[lang].services.service2_desc;

  // Contact
  document.querySelector('#contact h2').textContent = translations[lang].contact.title;
  document.querySelector('label[for="name"]').textContent = translations[lang].contact.name;
  document.querySelector('label[for="email"]').textContent = translations[lang].contact.email;
  document.querySelector('label[for="subject"]').textContent = translations[lang].contact.subject;
  document.querySelector('label[for="message"]').textContent = translations[lang].contact.message;
  document.querySelector('#contact-form button').textContent = translations[lang].contact.send;

  // Direction and lang
  document.documentElement.lang = lang;
  // Only Persian (fa) is RTL; English and Chinese are LTR.
  document.documentElement.dir = (lang === 'fa') ? 'rtl' : 'ltr';

  // Update page title
  document.title = titles[lang][currentPage] + ' • Holding Group 888';
}

langSelect.addEventListener('change', () => {
  currentLang = langSelect.value;
  applyTranslations(currentLang);
});

// ====== Form handling ======
const form = document.getElementById('contact-form');
const statusBox = document.getElementById('form-status');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  // Option B: Formspree (uncomment and put your endpoint)
  // const endpoint = 'https://formspree.io/f/YOUR_ENDPOINT';
  // const data = new FormData(form);
  // const res = await fetch(endpoint, { method: 'POST', body: data, headers: { 'Accept': 'application/json' } });
  // if (res.ok) {
  //   statusBox.textContent = translations[currentLang].contact.sent;
  //   form.reset();
  // } else {
  //   statusBox.textContent = 'خطا در ارسال. لطفاً دوباره تلاش کنید.';
  // }
  
  // Demo fallback:
  statusBox.textContent = translations[currentLang].contact.sent;
  form.reset();
});

// ====== Misc ======
document.getElementById('year').textContent = new Date().getFullYear();

// Initialize
applyTranslations(currentLang);
showPage(currentPage);
